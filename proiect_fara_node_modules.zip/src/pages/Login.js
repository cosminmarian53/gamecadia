function Login()
{
    document.getElementsByClassName("master").item(0).style.display = "none";

    return (
        <div>
            <h1>Login Page</h1>
            <p>Please enter your credentials to log in.</p>
        </div>
    );
}
export default Login;