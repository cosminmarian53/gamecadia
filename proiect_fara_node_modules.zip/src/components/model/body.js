import '../styles/body.css';

function Body({children}) {
  return (
    <div class='master'>
      {children}
    </div>
  );
}

export default Body;